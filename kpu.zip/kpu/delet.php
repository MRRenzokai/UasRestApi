<?php
require("koneksi.php");

$response = array();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $id = $_POST["id"];

    $perintah = "DELETE FROM tbl_kpu WHERE id = '$id'";
    $eksekusi = mysqli_query($konek, $perintah);
    $cek = mysqli_affected_rows($konek);

    if($cek > 0){
        $response["kode"] = 1;
        $response["pesan"] = "Data berhasil Di hapus";
    }
    else{
        $response["kode"] = 0;
        $response["pesan"] = "Gagal Menghapus data";

    }
   
    }
    else{
        $response["kode"] = 0;
        $response["pesan"] = "Tidak Ada Post data";
}
echo json_encode($response);
mysqli_close($konek);