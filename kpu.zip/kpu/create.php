<?php
require("koneksi.php");

$response = array();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $nama = $_POST["nama"];
    $kelamin = $_POST["kelamin"];
    $alamat = $_POST["alamat"];
    $nik = $_POST["nik"];

    $perintah = "INSERT INTO tbl_kpu (nama, kelamin, alamat, nik) values('$nama','$kelamin','$alamat','$nik')";
    $eksekusi = mysqli_query($konek, $perintah);
    $cek      = mysqli_affected_rows($konek);

    if($cek > 0){
        $response["kode"] = 1;
        $response["pesan"] = "Simpan Data Berhasil";
    }
    else{
        $response["kode"] = 0;
        $response["pesan"] = "Gagal Menyampaikan Data";
    }

}
else{
    $response["kode"] = 0;
    $response["pesan"] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($konek);