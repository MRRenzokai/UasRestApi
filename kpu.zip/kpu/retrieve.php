<?php
require("koneksi.php");
$perintah = "SELECT * FROM tbl_kpu";
$eksekusi = mysqli_query($konek, $perintah);
$cek = mysqli_affected_rows($konek);

if($cek > 0){
    $response["kode"] = 1;
    $response["pesan"] = "Data Tersedia";
    $response["data"] = array();

    while($ambil = mysqli_fetch_object($eksekusi)){

        $F["id"] = $ambil->id;
        $F["nama"] = $ambil->nama;
        $F["kelamin"] = $ambil->kelamin;
        $F["alamat"] = $ambil->alamat;
        $F["nik"] = $ambil->nik;


        array_push($response["data"], $F);
    }
}
else{
    $response["kode"] = 0;
    $response["pesan"] = "Data Tidak tersedia";
}

echo json_encode($response);
mysqli_close($konek);