<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "kpu";

$konek = mysqli_connect($host, $user, $pass, $db) or die("Database MYSQL Tidak terhubung");