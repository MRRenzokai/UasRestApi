package com.example.kpuindonesia.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.kpuindonesia.API.APIRequestsData;
import com.example.kpuindonesia.API.RetroServer;
import com.example.kpuindonesia.Adapter.AdapterData;
import com.example.kpuindonesia.MODEL.DataModel;
import com.example.kpuindonesia.MODEL.ResponseModel;
import com.example.kpuindonesia.R;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvdata;
    private RecyclerView.Adapter adData;
    private RecyclerView.LayoutManager lmData;
    private List<DataModel> listData = new ArrayList<>();
    private SwipeRefreshLayout srlData;
    private ProgressBar pbData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvdata = findViewById(R.id.rv_data);

        srlData = findViewById(R.id.srl_data);
        pbData = findViewById(R.id.pb_data);
        lmData = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false);
        rvdata.setLayoutManager(lmData);

        retrievedata();

        srlData.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                srlData.setRefreshing(true);
                retrievedata();
                srlData.setRefreshing(false);
            }
        });

    }

    public void retrievedata(){
        pbData.setVisibility(View.VISIBLE);
        APIRequestsData ardDATA = RetroServer.konekRetrofit().create(APIRequestsData.class);
        Call<ResponseModel>tampilData = ardDATA.ardRetrieveData();

        tampilData.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                int kode = response.body().getKode();
                String pesan = response.body().getPesan();

                Toast.makeText(MainActivity.this, "kode : "+kode+" | Pesan : ", Toast.LENGTH_SHORT).show();

                listData = response.body().getData();

                adData = new AdapterData(MainActivity.this,listData);
                rvdata.setAdapter(adData);
                adData.notifyDataSetChanged();

                pbData.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Gagal Menghubungi Server : "+t.getMessage(), Toast.LENGTH_SHORT).show();

                pbData.setVisibility(View.VISIBLE);

            }
        });
    }
}