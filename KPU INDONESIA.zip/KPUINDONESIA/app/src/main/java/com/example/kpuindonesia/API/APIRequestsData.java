package com.example.kpuindonesia.API;

import com.example.kpuindonesia.MODEL.ResponseModel;

import retrofit2.Call;
import retrofit2.http.GET;

public interface APIRequestsData {
    @GET("retrieve.php")
    Call<ResponseModel> ardRetrieveData();

}
