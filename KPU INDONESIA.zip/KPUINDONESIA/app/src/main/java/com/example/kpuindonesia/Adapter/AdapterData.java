package com.example.kpuindonesia.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kpuindonesia.MODEL.DataModel;
import com.example.kpuindonesia.R;

import java.util.List;

public class AdapterData extends RecyclerView.Adapter<AdapterData.HolderData>{
    private Context ctx;
    private List<DataModel> ListData;

    public AdapterData(Context ctx, List<DataModel> ListData) {
        this.ctx = ctx;
        this.ListData = ListData;
    }

    @NonNull
    @Override
    public HolderData onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item, parent,false);
        HolderData holder = new HolderData(layout);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull HolderData holder, int position) {
        DataModel dataModel = ListData.get(position);
        
        holder.tvid.setText(String.valueOf(dataModel.getId()));
        holder.tvnama.setText(dataModel.getNama());
        holder.tvkelamin.setText(dataModel.getKelamin());
        holder.tvalamat.setText(dataModel.getAlamat());
        holder.tvnik.setText(dataModel.getNik());
    }

    @Override
    public int getItemCount() {
        return ListData.size();
    }

    public class HolderData extends RecyclerView.ViewHolder {
        TextView tvid,tvnama, tvkelamin, tvalamat, tvnik;

        public HolderData(@NonNull View itemView) {
            super(itemView);
            
            tvid = itemView.findViewById(R.id.tv_id);
            tvnama = itemView.findViewById(R.id.tv_nama);
            tvkelamin = itemView.findViewById(R.id.tv_kelamin);
            tvalamat = itemView.findViewById(R.id.tv_alamat);
            tvnik = itemView.findViewById(R.id.tv_nik);
        }
    }
}
